import { randomUUID } from 'node:crypto'
import { selectRandomFigure } from '../lib/figureCatalog.js'
import { badRequest, notFound } from '../lib/errors.js'
import type { SecretFigure, YesNoAnswer } from '../lib/normalization.js'
import type {
  GameEventRepository,
  GameSessionRecord,
  GameSessionRepository,
} from '../repositories/gameSessionRepository.js'
import type { FigureScope, GuessVerdict, HostLlmService } from './hostLlmService.js'

export interface QuestionHistoryItem {
  question: string
  answer: YesNoAnswer
}

export interface GuessHistoryItem {
  guess: string
  isCorrect: boolean
}

export interface GameSessionSnapshot {
  sessionId: string
  status: 'playing' | 'ended'
  questionCount: number
  questionLimit: number
  remainingQuestions: number | null
  history: QuestionHistoryItem[]
  guesses: GuessHistoryItem[]
  revealedName?: string
}

export interface SubmitQuestionResponse {
  answer: YesNoAnswer
  status: 'playing' | 'ended'
  questionCount: number
  questionLimit: number
  remainingQuestions: number | null
  revealedName?: string
}

export interface SubmitGuessResponse extends GuessVerdict {
  status: 'ended'
}

interface GameSessionServiceParams {
  sessionRepository: GameSessionRepository
  eventRepository: GameEventRepository
  hostService: HostLlmService
}

export class GameSessionService {
  constructor(private readonly deps: GameSessionServiceParams) {}

  async createSession(input: { questionLimit: number; figureScope: FigureScope }): Promise<GameSessionSnapshot> {
    if (input.questionLimit < 0) {
      throw badRequest('提问次数上限不能小于 0')
    }

    const selectedFigure = selectRandomFigure(input.figureScope)
    const figure: SecretFigure = {
      name: selectedFigure.name,
      aliases: selectedFigure.aliases,
      era: selectedFigure.era,
    }
    const record = await this.deps.sessionRepository.createSession({
      id: randomUUID(),
      questionLimit: input.questionLimit,
      secretFigure: figure,
    })

    return this.buildSnapshot(record)
  }

  async getSessionSnapshot(sessionId: string): Promise<GameSessionSnapshot> {
    const record = await this.requireSession(sessionId)
    return this.buildSnapshot(record)
  }

  async submitQuestion(sessionId: string, question: string): Promise<SubmitQuestionResponse> {
    const trimmedQuestion = question.trim()
    if (!trimmedQuestion) {
      throw badRequest('问题不能为空')
    }

    const record = await this.requirePlayableSession(sessionId)
    const figure = this.getSecretFigure(record)
    const answer = await this.deps.hostService.answerQuestion({
      question: trimmedQuestion,
      figure,
    })

    const nextCount = record.questionCount + 1
    const limitReached = record.questionLimit > 0 && nextCount >= record.questionLimit
    const nextStatus = limitReached ? 'ended' : 'playing'
    const revealedName = limitReached ? record.secretFigureName : undefined

    await this.deps.eventRepository.appendQuestionEvent(sessionId, trimmedQuestion, answer)
    const updated = await this.deps.sessionRepository.updateSessionAfterQuestion(sessionId, {
      questionCount: nextCount,
      status: nextStatus,
      revealedName,
    })

    return {
      answer,
      status: updated.status,
      questionCount: updated.questionCount,
      questionLimit: updated.questionLimit,
      remainingQuestions: getRemainingQuestions(updated),
      ...(updated.revealedName ? { revealedName: updated.revealedName } : {}),
    }
  }

  async submitGuess(sessionId: string, guess: string): Promise<SubmitGuessResponse> {
    const trimmedGuess = guess.trim()
    if (!trimmedGuess) {
      throw badRequest('猜测不能为空')
    }

    const record = await this.requirePlayableSession(sessionId)
    const verdict = await this.deps.hostService.judgeGuess({
      guess: trimmedGuess,
      figure: this.getSecretFigure(record),
    })

    await this.deps.eventRepository.appendGuessEvent(sessionId, trimmedGuess, verdict.isCorrect)
    await this.deps.sessionRepository.updateSessionAfterGuess(sessionId, {
      revealedName: verdict.revealedName,
    })

    return {
      ...verdict,
      status: 'ended',
    }
  }

  private async requireSession(sessionId: string): Promise<GameSessionRecord> {
    const record = await this.deps.sessionRepository.findSessionById(sessionId)
    if (!record) {
      throw notFound('会话不存在')
    }

    return record
  }

  private async requirePlayableSession(sessionId: string): Promise<GameSessionRecord> {
    const record = await this.requireSession(sessionId)
    if (record.status === 'ended') {
      throw badRequest('当前会话已结束')
    }

    return record
  }

  private getSecretFigure(record: GameSessionRecord): SecretFigure {
    return {
      name: record.secretFigureName,
      aliases: record.secretFigureAliases,
      era: record.secretFigureEra,
    }
  }

  private async buildSnapshot(record: GameSessionRecord): Promise<GameSessionSnapshot> {
    const events = await this.deps.eventRepository.listSessionEvents({ sessionId: record.id })

    return {
      sessionId: record.id,
      status: record.status,
      questionCount: record.questionCount,
      questionLimit: record.questionLimit,
      remainingQuestions: getRemainingQuestions(record),
      history: events
        .filter(event => event.eventType === 'question' && event.questionText && event.answerText)
        .map(event => ({
          question: event.questionText!,
          answer: event.answerText!,
        })),
      guesses: events
        .filter(event => event.eventType === 'guess' && event.guessText && typeof event.isCorrect === 'boolean')
        .map(event => ({
          guess: event.guessText!,
          isCorrect: event.isCorrect!,
        })),
      ...(record.revealedName ? { revealedName: record.revealedName } : {}),
    }
  }
}

function getRemainingQuestions(record: Pick<GameSessionRecord, 'questionCount' | 'questionLimit'>): number | null {
  if (record.questionLimit <= 0) return null
  return Math.max(record.questionLimit - record.questionCount, 0)
}
