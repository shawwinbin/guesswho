import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it, vi } from 'vitest'
import { runMigrations } from './runMigrations.js'

describe('runMigrations', () => {
  it('executes sql files from the migrations directory in lexical order', async () => {
    const directory = mkdtempSync(join(tmpdir(), 'history-guess-migrations-'))

    try {
      writeFileSync(join(directory, '002_second.sql'), 'select 2;')
      writeFileSync(join(directory, '001_first.sql'), 'select 1;')

      const query = vi.fn(async () => undefined)

      await runMigrations({
        query,
        migrationsDir: directory,
      })

      expect(query).toHaveBeenNthCalledWith(1, 'select 1;')
      expect(query).toHaveBeenNthCalledWith(2, 'select 2;')
    } finally {
      rmSync(directory, { recursive: true, force: true })
    }
  })
})
