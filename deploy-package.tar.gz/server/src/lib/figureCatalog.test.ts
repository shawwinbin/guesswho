import { afterEach, describe, expect, it, vi } from 'vitest'
import { filterFiguresByScope, selectRandomFigure } from './figureCatalog.js'

describe('figureCatalog', () => {
  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('filters figures by the requested scope', () => {
    const poets = filterFiguresByScope('poet')
    const tangSongFigures = filterFiguresByScope('tang-song')

    expect(poets.length).toBeGreaterThan(0)
    expect(poets.every(figure => figure.role === '诗人')).toBe(true)
    expect(tangSongFigures.length).toBeGreaterThan(0)
    expect(tangSongFigures.every(figure => ['唐朝', '宋朝'].includes(figure.era))).toBe(true)
  })

  it('selects different figures when random values point at different indices', () => {
    vi.spyOn(Math, 'random')
      .mockReturnValueOnce(0)
      .mockReturnValueOnce(0.99)

    const first = selectRandomFigure('all')
    const second = selectRandomFigure('all')

    expect(first.name).not.toBe(second.name)
  })
})
