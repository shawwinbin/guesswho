import { figures } from '../data/figures.js'
import type { FigureScope, HistoricalFigure } from '../types/figure.js'

export function filterFiguresByScope(scope: FigureScope): HistoricalFigure[] {
  switch (scope) {
    case 'poet':
      return figures.filter(figure => figure.role === '诗人')
    case 'emperor':
      return figures.filter(figure => figure.role === '皇帝')
    case 'military':
      return figures.filter(figure => figure.isMilitaryLeader)
    case 'philosopher':
      return figures.filter(figure => figure.isPhilosopher)
    case 'female':
      return figures.filter(figure => figure.gender === '女')
    case 'tang-song':
      return figures.filter(figure => ['唐朝', '宋朝'].includes(figure.era))
    case 'all':
    default:
      return figures
  }
}

export function selectRandomFigure(scope: FigureScope): HistoricalFigure {
  const candidates = filterFiguresByScope(scope)
  if (candidates.length === 0) {
    throw new Error(`No figures available for scope: ${scope}`)
  }

  const index = Math.floor(Math.random() * candidates.length)
  return candidates[index]
}
